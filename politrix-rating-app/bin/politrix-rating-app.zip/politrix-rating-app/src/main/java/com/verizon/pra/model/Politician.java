package com.verizon.pra.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "politician")
public class Politician {
	
	
	@OneToMany(mappedBy="politicians",cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	private List<Activity> act;
	@Id
	private int pId;
	
	private String pname;

	public int getpId() {
		return pId;
	}

	public void setpId(int pId) {
		this.pId = pId;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}	

}
